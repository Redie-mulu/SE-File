package com.soroncho.patient.patientApp.service;

import com.soroncho.patient.patientApp.entity.Patient;

import java.util.List;

public interface PatientService {
    public List<Patient> findAll();

}
